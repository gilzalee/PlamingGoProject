package com.tech.PlamingGo.controller;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;
import com.tech.PlamingGo.dao.DramaDao;
import com.tech.PlamingGo.dto.DramaDto;

@Controller
public class DramaController_admin {

	@Autowired
	private SqlSession sqlSession;
	
	// 01.	드라마 등록하기 위한 전환
	@RequestMapping("drama/insert")
	public String insert() {
		System.out.println("01. insert 지나감");
		return "drama/insert";
	}

	// 02.	드라마 등록 페이지
	@RequestMapping("drama/insert_page")
	public String insert_page(HttpServletRequest request, Model model) throws Exception{
		System.out.println("02. insert_page 지나감");
		// Mybatis
		// 파일 업로드 될 경로
		String attachPath = "resources\\upload\\";
		String uploadPath = 
				request.getSession().getServletContext().getRealPath("/");
		String path = uploadPath + attachPath;
		
		// 파일 첨부 (MultipartRequest 이용 → cos.jar 라이브러리 필요!)
		// request객체 + 저장 될 서버 경로 + 파일의 최대 크기 + 인코딩 방식 + 중복 파일 처리 방식
		MultipartRequest req =
				new MultipartRequest(request, path, 
						10*1024*1024, "UTF-8", new DefaultFileRenamePolicy());
			
		// enctype을 'multipart/form-data'로 선언하고 submit한 데이터들은 
		// request 객체가 아닌 MultipartRequest객체인 req로 불러와야 함
		// 파라미타 값
		String img = req.getFilesystemName("img");
		String title = req.getParameter("title");
		String rating = req.getParameter("rating"); 
		String opendate = req.getParameter("opendate");
		String nation = req.getParameter("nation");
		String age = req.getParameter("age");
		String epi = req.getParameter("epi");
		String director = req.getParameter("director");
		String actor = req.getParameter("actor");
		String genre = req.getParameter("genre");
		String summary = req.getParameter("summary");
		
		// Mybatis 연결
		DramaDao dramadao = sqlSession.getMapper(DramaDao.class);
		dramadao.insert_page(img, title, rating, opendate, nation, age, epi, director, actor, genre, summary);
		
		return "redirect:../drama";
	}
	
	// 03. 상세뷰(drama_detailview) → 수정페이지(drama/modify)로 전환
	@RequestMapping("drama/modify") 
	public String modify(HttpServletRequest request, Model model) { 
		System.out.println("01. modify 지나감"); 
		// drama_detailview에서 hidden으로 보낸 파라미터 값 c를 request하여 가져옴 
		String code = request.getParameter("c");
	  
		// code에 해당하는 detailview의 모든 정보 가져오기 
		DramaDao dao = sqlSession.getMapper(DramaDao.class); 
		DramaDto dto = dao.modify(code);
	  
	  	// dto를 model에 add하여 modify라는 이름으로 modify.jsp 뷰단에 넘겨주기
		model.addAttribute("modify", dto);
	  
		return "drama/modify";
	 }
	 
	
	// 04.	드라마 수정 페이지
	@RequestMapping(value = "drama/modify_page",method = RequestMethod.GET)
	public String modify_page(HttpServletRequest request, Model model) {
		System.out.println("02. modify_page 지나감");
		
		// modify.jsp 뷰단에서 보낸 name값=파라미타 값 가져오기
		String code = request.getParameter("c");
		
		String img = request.getParameter("img");
		String title = request.getParameter("title");
		String rating = request.getParameter("rating"); 
		String opendate = request.getParameter("opendate");
		String nation = request.getParameter("nation");
		String age = request.getParameter("age");
		String epi = request.getParameter("epi");
		String director = request.getParameter("director");
		String actor = request.getParameter("actor");
		String genre = request.getParameter("genre");
		String summary = request.getParameter("summary");
		
		DramaDao dao = sqlSession.getMapper(DramaDao.class);
		dao.modify_page(code, img, title, rating, opendate, nation, age, epi, director, actor, genre, summary);
		
		return "redirect:../drama_detailview?c="+code;
	}
	
	
	// 05.	드라마 삭제 페이지
	@RequestMapping("drama/delete")
	public String delete(HttpServletRequest request, Model model) {
		String code = request.getParameter("c");
		
		DramaDao dao = sqlSession.getMapper(DramaDao.class);
		dao.delete(code);
		
		return "redirect:../drama";
	}

}
