package com.tech.PlamingGo.dao;

import java.util.ArrayList;

import com.tech.PlamingGo.dto.QnaDto;

public interface QnaDao {
	public ArrayList<QnaDto> c_list(); //boarddao 에있는 list를 추상메소드로 지정 (ArrayList<BoardDto>는 리턴타입)	 
	public void c_write(String qna_writer, String qna_title,
			String qna_content, String fName);
	public QnaDto contentView(String qna_num);
	public void upHit(String strid);
	public void c_modify(String qna_num, String qna_writer, 
			String qna_title, String qna_content);
	
}
