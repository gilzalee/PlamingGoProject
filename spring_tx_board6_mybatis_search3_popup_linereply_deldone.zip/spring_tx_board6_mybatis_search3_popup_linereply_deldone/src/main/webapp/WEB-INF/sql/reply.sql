create table mvc_boardreply(
    rid number,
    rseq number PRIMARY key,
    rname varchar2(30),
    rcontent varchar2(100),
    rdate DATE,
    
    constraint fk_rid
    foreign key(rid)
    REFERENCES mvc_board(bid)
    on delete cascade//원글 삭제시 자동삭제 되도록
);
create sequence brdreply_seq increment by 1 start with 1;

alter table mvc_boardreply
add constraint fk_rid
foreign key(rid)
REFERENCES mvc_board(bid)
on delete cascade;


select MVC_BOARD_SEQ.nextval from dual;
select MVC_BOARD_SEQ.CURRVAL from dual;

select last_number from user_sequences where sequence_name='MVC_BOARD_SEQ';

select * from mvc_boardreply;
drop table mvc_boardreply;

INSERT ALL INTO MVC_BOARD(BID,BNAME,BTITLE,
					BCONTENT, BHIT,BGROUP,BSTEP,BINDENT,FILESRC)
					 VALUES(MVC_BOARD_SEQ.NEXTVAL,
					'cc','title','content',0,
					MVC_BOARD_SEQ.CURRVAL,0,0,null)
		INTO MVC_BOARDREPLY(RID,RNAME,RCONTENT)
		VALUES(MVC_BOARD_SEQ.CURRVAL,'cc','content') select * from dual;

select max(bid) from mvc_board;         
 ROLLBACK;
 select * from mvc_board;
 select * from dual;  
 commit;