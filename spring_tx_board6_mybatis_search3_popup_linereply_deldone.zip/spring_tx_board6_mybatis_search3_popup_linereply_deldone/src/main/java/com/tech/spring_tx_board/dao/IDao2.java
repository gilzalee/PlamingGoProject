package com.tech.spring_tx_board.dao;

public interface IDao2 {
		
	
	public int selectBoardCount(String searchKeyword,String selNum);
////	public int selectBoard2Count0(String searchKeyword);
////	public int selectBoard2Count1(String searchKeyword);
////	public int selectBoard2Count2(String searchKeyword);
////	public int selectBoard2Count3(String searchKeyword);
	
	
	
	
}
