package com.tech.spring_tx_board.controller;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.tech.spring_tx_board.dao.IDao;
import com.tech.spring_tx_board.dao.IDao2;
import com.tech.spring_tx_board.vopage.SearchVO;

@Controller
public class BController2 {
//	BServiceInp commandInp;
	
	@Autowired
	private SqlSession sqlSession;
	
//	public JdbcTemplate template;
//
//	public void setTemplate(JdbcTemplate template) {
//		this.template = template;
//		Constant.template=this.template;
//	}

	@RequestMapping("/list")
	public String list(HttpServletRequest request,
			SearchVO searchVo, Model model) {
		System.out.println("BController2 > pass list()");
//		search
		String btitle="";
		String bcontent="";
		
		String[] brdtitle=
				request.getParameterValues("searchType");

		if (brdtitle!=null) {
			for (String val : brdtitle) {
				if(val.equals("btitle")) {
					model.addAttribute("btitle","true");
					btitle="btitle";
				}else if(val.equals("bcontent")) {
					model.addAttribute("bcontent","true");
					bcontent="bcontent";
				}	
			}
		}
		
		String searchKeyword=request.getParameter("sk");
		if(searchKeyword==null) {
			searchKeyword="";
		}
		
		
		IDao dao = sqlSession.getMapper(IDao.class);
		
		IDao2 dao2 = sqlSession.getMapper(IDao2.class);
		
		int total=0;
		
		if(btitle.equals("btitle") && bcontent.equals("")) {
			 total=dao2.selectBoardCount(searchKeyword ,"1" );
			System.out.println("go total >list1");
		}else if(btitle.equals("") && bcontent.equals("bcontent")) {
			 total=dao2.selectBoardCount(searchKeyword, "2" );
			System.out.println("go total >list2");
		}else if(btitle.equals("btitle") && bcontent.equals("bcontent")) {
			 total=dao2.selectBoardCount(searchKeyword, "3" );
			System.out.println("go total >list3");
		}else if(btitle.equals("") && bcontent.equals("")) {
			 total=dao2.selectBoardCount(searchKeyword, "0" );
			System.out.println("go total >list0");
		}
		
		//pageVO=new PageVO();
		String strPage=request.getParameter("page");
		
		System.out.println("searchKeyword >>"+searchKeyword);
		model.addAttribute("searchKeyword",searchKeyword);
		
		System.out.println("strPage >>"+strPage);

			if(strPage==null || strPage.equals("")) {
				strPage="1";
			}
		System.out.println("strPage >>"+strPage);

		int page=Integer.parseInt(strPage);
		searchVo.setPage(page);
		
		searchVo.pageCalculate(total);

		System.out.println("레코드 총수 "+ dao2.selectBoardCount(searchKeyword, "0" ));
		
		
		System.out.println("====================");
		System.out.println("clickPage : "+searchVo.getPage());
		System.out.println("pageStart : "+searchVo.getPageStart());
		System.out.println("pageEnd : "+searchVo.getPageEnd());
		System.out.println("pageTot : "+searchVo.getTotPage());
		System.out.println("rowStart : "+searchVo.getRowStart());
		System.out.println("rowEnd : "+searchVo.getRowEnd());
		
		int rowStart=searchVo.getRowStart();
		int rowEnd=searchVo.getRowEnd();
		
//		select check query
		System.out.println("btitle>>>>>>"+btitle);
		System.out.println("bcontent>>>>>>"+bcontent);
		
		if(btitle.equals("btitle") && bcontent.equals("")) {
			model.addAttribute("list", dao.list(rowStart,rowEnd,searchKeyword,"1"));
			model.addAttribute("totRowCnt", dao2.selectBoardCount(searchKeyword,"1"));
			System.out.println("gogo >list1");
		}else if(btitle.equals("") && bcontent.equals("bcontent")) {
			model.addAttribute("list", dao.list(rowStart,rowEnd,searchKeyword,"2"));
			model.addAttribute("totRowCnt", dao2.selectBoardCount(searchKeyword,"2"));
			System.out.println("gogo >list2");
		}else if(btitle.equals("btitle") && bcontent.equals("bcontent")) {
			model.addAttribute("list", dao.list(rowStart,rowEnd,searchKeyword,"3"));
			model.addAttribute("totRowCnt", dao2.selectBoardCount(searchKeyword,"3"));
			System.out.println("gogo >list3");
		}else if(btitle.equals("") && bcontent.equals("")) {
			model.addAttribute("list", dao.list(rowStart,rowEnd,searchKeyword,"0"));
			model.addAttribute("totRowCnt", dao2.selectBoardCount(searchKeyword,"0"));
			System.out.println("gogo >list0");
		}
//		
//		model.addAttribute("totalcnt", total);
//		model.addAttribute("list", dao.list(rowStart,rowEnd));
		model.addAttribute("searchVo",searchVo);
//		
		return "list";
	}
	
	
}
