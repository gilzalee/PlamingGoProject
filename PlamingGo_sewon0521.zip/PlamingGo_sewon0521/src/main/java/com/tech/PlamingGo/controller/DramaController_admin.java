package com.tech.PlamingGo.controller;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class DramaController_admin {

	@Autowired
	private SqlSession sqlsession;
	
	// 01.	드라마 리스트 등록
	@RequestMapping("drama/list_write")		//	주소창
	public String list_write() {
		
		return "drama/list_write";			//	이동경로
	}
	
	// 02.	드라마 리스트 수정
	@RequestMapping("drama/list_modify")
	public String list_modify() {
		
		return "drama/list_modify";
	}
	
	// 03.	드라마 리스트 삭제
	@RequestMapping("drama/list_delete")
	public String list_delete() {
		
		return "drama/list_delete";
	}
	
	// 04.	드라마 상세보기 등록
	@RequestMapping("drama/detail_write")
	public String detail_write() {
		
		return "drama/detail_write";
	}
	
	// 05.	드라마 상세보기 수정
	@RequestMapping("drama/detail_modify")
	public String detail_modify() {
		
		return "drama/detail_modify";
	}
	
	// 06.	드라마 상세보기 삭제
	@RequestMapping("drama/detail_delete")
	public String detail_delete() {
		
		return "drama/detail_delete";
	}

}
