package com.tech.PlamingGo.dao;

import java.util.ArrayList;

import com.tech.PlamingGo.dto.DramaDto;

public interface DramaDao {
	
	public ArrayList<DramaDto> drama(int start, int end);	// 드라마 리스트 가져오기
	public DramaDto drama_detailview(String code); 			// 상세페이지
	public int selectDramaCount();							// 페이징 처리 中 전체 드라마 데이터 개수(totDrama)알아내기
	public void upHit(String code);							// 조회수 증가
	
	// 관리자 드라마 정보 등록
	public void insert_page(String img, String title,
			String opendate, String nation,
			String age, String epi, String director, 
			String actor, String genre, String summary);	
	
	
}
