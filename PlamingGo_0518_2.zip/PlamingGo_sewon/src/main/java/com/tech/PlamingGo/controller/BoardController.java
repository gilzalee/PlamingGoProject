package com.tech.PlamingGo.controller;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.tech.PlamingGo.dao.DramaDao;
import com.tech.PlamingGo.dto.DramaDto;
import com.tech.PlamingGo.page.SearchVo;

@Controller
public class BoardController {
	
	// SqlSession 
	// @AutoWired : 각 상황의 타입에 맞는 loC컨테이너 안에 존재하는 Bean 자동 주입
	@Autowired
	private SqlSession sqlSession;
	
	
	// 드라마 리스트 ▶ 사용자 화면
	@RequestMapping("/drama")
	public String drama(Model model, HttpServletRequest request, SearchVo searchVo) {
	// SearchVo 는 PageVo 를 상속 받으므로, SearchVo 만 가져와도 PageVo를 같이 가져오는 격.
		
		// ******************** 페이징 처리 ********************
		// drama 가 최초 실행될 때 화면에 나타나는 페이지 = 1 페이지 
		// ★ ★ strPage 는 최초값이 null이므로, null일때 1로 값을 주어야지만 1 페이지 링크 클릭 시, strPage=1로 신호가 들어온다!!
		// 2 페이지 링크 클릭 시, strPage=2 ...
		// 파라미타 값 page는 사용자가 누르는 숫자페이지(request:요청)에서 가져와서 strPage로 받아주어야 페이지지정 가능. 지정 안하면 오류 남!
		String strPage = request.getParameter("page");
			if (strPage==null) {
				strPage="1";
			}
		
		// PageVo에서 page는 Integer타입이므로, strPage의 타입을 String → Integer 타입으로 변환
		int intpage=Integer.parseInt(strPage);
		
		// Integer 타입으로 변환한 intpage를 담아와서 searchVo의 현재페이지로 set
		searchVo.setPage(intpage);
		
		// db의 데이터 연결 ... mybatis ... (dao 패키지의 인터페이스 DramaDao & mapper 패키지의 DramaDao.xml)
		// 인터페이스 DramaDao와 DramaDao.xml이 연관이 있음
		DramaDao dramadao=sqlSession.getMapper(DramaDao.class);
		
		// db 속 드라마 데이터 전체 개수
		int totDrama=dramadao.selectDramaCount();
		
		// PageVo의 메소드 pageCalculate에 totDrama를 가져가게 되고 알아서 페이지 수 알아서 계산됨!!
		// SearchVo는 PageVo를 상속받으므로, PageVo의 메소드 사용 가능.
		searchVo.pageCalculate(totDrama);
		
		int rowStart=searchVo.getRowStart();		// 시작 행 가져오기 (..1 페이지의 시작 번호)
		int rowEnd=searchVo.getRowEnd();			// 종료 행 가져오기 (..1 페이지의 종료 번호)
		
		
		// ******************** 드라마 리스트 화면에 띄우기 ********************
		model.addAttribute("drama", dramadao.drama());	// View단인 drama.jsp로 ${drama}값 보내기
		model.addAttribute("tot_drama_cnt", totDrama);	// 전체 드라마 데이터 수 보내기
		model.addAttribute("pageVo", searchVo);			// searchVo의 데이터 모두 pageVo 이름으로 보내기
		
		return "drama";
	}
	
	
	// 드라마 제목 누르면 드라마 상세보기 ▶ 사용자 화면
	@RequestMapping("/drama_detailview")
	public String drama_detailview(Model model, HttpServletRequest request) {
		
		// 기본키의 값(drama_code)을 xml에서 String 타입으로 가져옴
		String drama_code=request.getParameter("drama_code");
		
		DramaDao dramadao=sqlSession.getMapper(DramaDao.class);
		DramaDto dramadto=dramadao.drama_detailview(drama_code); 
		
		//dramadto를 detail_view 라는 이름으로 drama_detailview 로 보내줌(View단)
		model.addAttribute("detailview", dramadto);
		
		return "drama_detailview";
	}
	
	
	// 드라마 리뷰게시판 ▶ 사용자 화면
	@RequestMapping("drama_review")
	public String drama_review() {
		
		return "drama_review";
	}
	
	
}
