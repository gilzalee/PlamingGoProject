package com.tech.PlamingGo.dao;

import java.util.ArrayList;

import com.tech.PlamingGo.dto.DramaDto;

public interface DramaDao {
	
	public ArrayList<DramaDto> drama();						// 드라마 리스트
	public DramaDto drama_detailview(String drama_code); 	// 해당코드에 맞는 드라마 상세보기
	public int selectDramaCount();							// 페이징 처리 中 전체 드라마 데이터 개수(totDrama)알아내기
	
	
	
}
