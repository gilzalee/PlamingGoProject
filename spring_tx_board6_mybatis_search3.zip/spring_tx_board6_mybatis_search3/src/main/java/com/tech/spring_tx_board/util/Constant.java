package com.tech.spring_tx_board.util;

import org.springframework.jdbc.core.JdbcTemplate;

public class Constant {
	public static JdbcTemplate template;
	//JdbcTemplate 사용할때

}
