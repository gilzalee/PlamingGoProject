package com.tech.spring_tx_board.controller;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class LoginController {
//	BServiceInp commandInp;
	
	@Autowired
	private SqlSession sqlSession;

	@RequestMapping("login")
	public String login() {
		System.out.println("login()");
		return "login/loginForm";
	}
	
	@RequestMapping("loginProc")
	public String loginProc(HttpServletRequest request,
			Model model) {
		System.out.println("loginProc()");
		String uid=request.getParameter("id");
		System.out.println("loginProc()~~~");
		
//		일치처리
		request.getSession().setAttribute("uid", uid);
		
		return "redirect:list";
	}
	
	
	
//	@RequestMapping(value = "/reply")
//	public String reply(HttpServletRequest request,
//			Model model) {
//		System.out.println("pass reply()");
////		model.addAttribute("request", request);
////		commandInp=new BReplyService();
////		commandInp.execute(model);
//		
//		String bid=request.getParameter("bid");
//		String bname=request.getParameter("bname");
//		String btitle=request.getParameter("btitle");
//		String bcontent=request.getParameter("bcontent");
//		String bgroup=request.getParameter("bgroup");
//		String bstep=request.getParameter("bstep");
//		String bindent=request.getParameter("bindent");
//		
//		IDao dao=sqlSession.getMapper(IDao.class);
//		dao.stepup(bgroup, bstep);
//		dao.reply(bid, bname, btitle, 
//				bcontent, bgroup,
//				bstep, bindent);
//		
//		return "redirect:list";
//	}
	
	
	
}
