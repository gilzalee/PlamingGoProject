package com.tech.PlamingGo.controller;

import java.io.IOException;
import java.lang.ProcessBuilder.Redirect;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;
import com.tech.PlamingGo.dao.MovieDao;
import com.tech.PlamingGo.dto.MovieDto;
import com.tech.PlamingGo.dto.ReviewDto;
import com.tech.PlamingGo.vopage.SearchVO;

@Controller
public class MovieController {

	// SqlSession
	// @AutoWired : 각 상황의 타입에 맞는 loC컨테이너 안에 존재하는 Bean 자동 주입
	@Autowired
	private SqlSession sqlSession;
	

	@RequestMapping("/movie")
	public String getmovielist(Model model, HttpServletRequest request, SearchVO searchVo) {
		System.out.println("Get movielist");
		// search
		String movie_title = "";
		String movie_genre = "";
		String movie_nation = "";

		String[] MVtitle = request.getParameterValues("searchType");
		if (MVtitle != null) {
			for (String val : MVtitle) {
				if (val.equals("movie_title")) {
					model.addAttribute("movie_title", "true");
					movie_title = "movie_title";
				} else if (val.equals("movie_genre")) {
					model.addAttribute("movie_genre", "true");
					movie_genre = "movie_genre";
				} else if (val.equals("movie_nation")) {
					model.addAttribute("movie_nation", "true");
					movie_nation = "movie_nation";
				}
			}
		}
		// list단의 keyword를 가져오기
		String searchKeyword = request.getParameter("keyword");
		if (searchKeyword == null) {
			searchKeyword = "";
		}

		MovieDao dao = sqlSession.getMapper(MovieDao.class);
		int total = 0;

		if (movie_title.equals("movie_title") && movie_genre.equals("") && movie_nation.equals("")) {
			total = dao.selectBoardCount(searchKeyword, "1");
		} else if (movie_title.equals("") && movie_genre.equals("movie_genre") && movie_nation.equals("")) {
			total = dao.selectBoardCount(searchKeyword, "2");
		} else if (movie_title.equals("") && movie_genre.equals("") && movie_nation.equals("movie_nation")) {
			total = dao.selectBoardCount(searchKeyword, "3");
		}

		String strPage = request.getParameter("page");// 페이지 가져오기(리스트에서)
		model.addAttribute("searchKeyword", searchKeyword);// 값 보내주기

		if (strPage == null || strPage.equals("")) {
			strPage = "1";
		}

		int page = Integer.parseInt(strPage);
		searchVo.setPage(page);

		searchVo.pageCalculate(total);

		int rowStart = searchVo.getRowStart();
		int rowEnd = searchVo.getRowEnd();

		// select check query(옵션으로 바꿔주기)

		if (movie_title.equals("movie_title") && movie_genre.equals("")) {
			/* model.addAttribute("getmovielist", dao.getmovielist(row)); */
		}

		model.addAttribute("getmovielist", dao.getmovielist());// 모델에 담아보내는 이름이 메소드 이름과 일치하는지 꼭 꼭 확인하기

		return "movie";

	}

	@RequestMapping("/moviedetail")
	public String moviedetail(Model model, HttpServletRequest request) {
		System.out.println("moviedetail!!");
		String movie_code = request.getParameter("movie_code");// list페이지에서 보내준 코드 값을 가져와야 내용 출력이 됨
		
		MovieDao Mdao = sqlSession.getMapper(MovieDao.class);
		MovieDto Mdto = Mdao.movie_detail(movie_code);
		model.addAttribute("movie_detail", Mdto);
		System.out.println(movie_code+"=MOVIE code!!");
		
		
		ArrayList<MovieDto> review_list = Mdao.review_list(movie_code);
		/*
		 * for(MovieDto var : review_list) {
		 * System.out.println(var.getMreview_content()); }
		 */
		  
		  model.addAttribute("review_list", review_list);
		  
		 
		

		return "moviedetail";

	}

	


	@RequestMapping("/movie_insert")
	public String movie_insert(HttpServletRequest request, Model model) {
		System.out.println("insert()!");

		return "movie_insert";

	}

	@RequestMapping("/movie_insert_page")
	public String movie_insert_page(HttpServletRequest request, Model model) throws Exception {
		// 파일이 업로드 될 경로 구해주기
		String attachPath = "resources\\upload\\";
		String uploadPath = request.getSession().getServletContext().getRealPath("/");
		String path = uploadPath + attachPath;

		// MultipartRequest로 파일 올리기
		// request객체 + 저장 될 서버 경로+ 파일의 최대크기 +인코딩(영어 한글)방식+ 중복 파일 처리 방식
		MultipartRequest req = new MultipartRequest(request, path, 10 * 1024 * 1024, "UTF-8",
				new DefaultFileRenamePolicy());

		// enctype을 "multipart/form-data"로 선언하고 submit한 데이터들은 request객체가 아닌
		// MultipartRequest객체로 불러와야 한다.
		String movie_title = req.getParameter("movie_title");
		String movie_img = req.getFilesystemName("movie_img");// getFilesystemName로 가져오기
		String movie_age = req.getParameter("movie_age");
		String movie_time = req.getParameter("movie_time");
		String movie_summary = req.getParameter("movie_summary");
		String movie_director = req.getParameter("movie_director");
		String movie_actor = req.getParameter("movie_actor");
		String movie_genre = req.getParameter("movie_genre");
		String movie_nation = req.getParameter("movie_nation");
		String movie_date = req.getParameter("movie_date");

		/*
		 * if (movie_img==null) { movie_img=""; }
		 */

		MovieDao dao = sqlSession.getMapper(MovieDao.class);

		dao.movie_insert_page(movie_title, movie_img, movie_age, movie_time, movie_summary, movie_director, movie_actor,
				movie_genre, movie_nation, movie_date);

		System.out.println("업로드 패스 " + path);

		return "redirect:movie";

	}

	@RequestMapping("/movie_modify")
	public String movie_modify(HttpServletRequest request, Model model) {

		String movie_code = request.getParameter("movie_code");

		MovieDao Mdao = sqlSession.getMapper(MovieDao.class);
		MovieDto Mdto = Mdao.movie_detail(movie_code);

		model.addAttribute("movie_modify", Mdto);// model로 moviedetail의 코드 값을 담아서 movie_modify로 이름 지어준 후 modify쪽에
		// 데이터에서 불러올 값과 코드(movie_modify)를 넣어주면 수정화면에서 해당 데이터를 불러올 수 있다

		System.out.println("modify " + movie_code + " 페이지로 이동중()!");

		return "movie_modify";

	}

	@RequestMapping("/movie_modify_view") // 영화쪽 수정
	public String movie_modify_view(HttpServletRequest request, Model model) {

		System.out.println("pass modify_view()");

		String movie_code = request.getParameter("movie_code");
		String movie_title = request.getParameter("movie_title");
		String movie_img = request.getParameter("movie_img");
		String movie_age = request.getParameter("movie_age");
		String movie_time = request.getParameter("movie_time");
		String movie_summary = request.getParameter("movie_summary");
		String movie_director = request.getParameter("movie_director");
		String movie_actor = request.getParameter("movie_actor");
		String movie_genre = request.getParameter("movie_genre");
		String movie_nation = request.getParameter("movie_nation");
		String movie_date = request.getParameter("movie_date");
		MovieDao Mdao = sqlSession.getMapper(MovieDao.class);

		Mdao.movie_modify_view(movie_code, movie_title, movie_img, movie_age, movie_time, movie_summary, movie_director,
				movie_actor, movie_genre, movie_nation, movie_date);

		System.out.println(movie_code + movie_title + movie_age);

		return "redirect:movie";

	}

	@RequestMapping("/movie_delete") // 영화쪽 삭제
	public String movie_delete(HttpServletRequest request, Model model) {
		String movie_code = request.getParameter("movie_code");

		MovieDao dao = sqlSession.getMapper(MovieDao.class);
		dao.movie_delete(movie_code);

		return "redirect:movie";

	}
//////////////////리뷰 insert, modify, delete, rating controller///////////////////////

	
	
	 

	@RequestMapping("/review_insert")
	public String review_insert(HttpServletRequest request, Model model) {
		System.out.println("review-insert()!");

		String join_code = request.getParameter("join_code");
		String mreivew_writer = request.getParameter("mreview_writer");
		String mreview_content = request.getParameter("mreview_content");
		String mreview_date = request.getParameter("mreview_date");

		MovieDao Mdao = sqlSession.getMapper(MovieDao.class);// mapper에 있는 데이터 가져오기

		Mdao.review_insert(join_code,mreivew_writer,mreview_content, mreview_date);
		model.addAttribute("movie_code", join_code);//join_code보낸거 받기//이름이 movie_code인지는 디테일단에서 확인

		System.out.println(join_code+"~~");
		
		return "redirect:moviedetail";

	}

	
	@RequestMapping("/review_delete")
	public String review_delete(HttpServletRequest request, Model model) {

		String review_num = request.getParameter("review_num");
		String join_code = request.getParameter("join_code");

		MovieDao dao = sqlSession.getMapper(MovieDao.class);
		dao.review_delete(review_num);
		model.addAttribute("movie_code",join_code);

		return "redirect:moviedetail";

	}
	
	


}
