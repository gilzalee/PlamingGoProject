package com.tech.PlamingGo.dto;

public class WishDto {

/*
	  wishcode 	NUMBER 			보고싶어요 코드
	  userid 	varchar2(20) 	사용자 아이디
	  ctscode 	NUMBER			드라마 코드
*/
	
	private int wishcode;
	private String userid;
	private int ctscode;
	
	
	public int getWishcode() {
		return wishcode;
	}
	public void setWishcode(int wishcode) {
		this.wishcode = wishcode;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public int getCtscode() {
		return ctscode;
	}
	public void setCtscode(int ctscode) {
		this.ctscode = ctscode;
	}
	
	
	
}
