create table mvc_board(
bid number(4) primary key,
bname varchar2(20),
btitle varchar2(100),
bcontent varchar2(300),
bdate Date default sysdate,
bhit number(4) default 0,
bgroup number(4),
bstep number(4),
bindent number(4));

create SEQUENCE mvc_board_seq;

select * from mvc_board;
insert into mvc_board 
values(mvc_board_seq.nextval,'cj','java1','java111',
sysdate,0,MVC_BOARD_SEQ.currval,0,0);
commit;
delete mvc_board;