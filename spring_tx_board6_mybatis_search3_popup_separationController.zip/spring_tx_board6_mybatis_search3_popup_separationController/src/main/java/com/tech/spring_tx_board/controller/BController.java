package com.tech.spring_tx_board.controller;

import java.io.FileInputStream;
import java.net.URLEncoder;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;
import com.tech.spring_tx_board.dao.IDao;
import com.tech.spring_tx_board.dto.BoardDto;

@Controller
public class BController {
//	BServiceInp commandInp;
	
	@Autowired
	private SqlSession sqlSession;
	
//	public JdbcTemplate template;
//
//	public void setTemplate(JdbcTemplate template) {
//		this.template = template;
//		Constant.template=this.template;
//	}

//	@RequestMapping("/list")
//	public String list(HttpServletRequest request,
//			SearchVO searchVo, Model model) {
//		System.out.println("pass list()");
////		search
//		String btitle="";
//		String bcontent="";
//		
//		String[] brdtitle=
//				request.getParameterValues("searchType");
//
//		if (brdtitle!=null) {
//			for (String val : brdtitle) {
//				if(val.equals("btitle")) {
//					model.addAttribute("btitle","true");
//					btitle="btitle";
//				}else if(val.equals("bcontent")) {
//					model.addAttribute("bcontent","true");
//					bcontent="bcontent";
//				}	
//			}
//		}
//		
//		String searchKeyword=request.getParameter("sk");
//		if(searchKeyword==null) {
//			searchKeyword="";
//		}
//		
//		
//		IDao dao = sqlSession.getMapper(IDao.class);
//		
//		IDao2 dao2 = sqlSession.getMapper(IDao2.class);
//		
//		int total=0;
//		
//		if(btitle.equals("btitle") && bcontent.equals("")) {
//			 total=dao2.selectBoardCount(searchKeyword ,"1" );
//			System.out.println("go total >list1");
//		}else if(btitle.equals("") && bcontent.equals("bcontent")) {
//			 total=dao2.selectBoardCount(searchKeyword, "2" );
//			System.out.println("go total >list2");
//		}else if(btitle.equals("btitle") && bcontent.equals("bcontent")) {
//			 total=dao2.selectBoardCount(searchKeyword, "3" );
//			System.out.println("go total >list3");
//		}else if(btitle.equals("") && bcontent.equals("")) {
//			 total=dao2.selectBoardCount(searchKeyword, "0" );
//			System.out.println("go total >list0");
//		}
//		
//		//pageVO=new PageVO();
//		String strPage=request.getParameter("page");
//		
//		System.out.println("searchKeyword >>"+searchKeyword);
//		model.addAttribute("searchKeyword",searchKeyword);
//		
//		System.out.println("strPage >>"+strPage);
//
//			if(strPage==null || strPage.equals("")) {
//				strPage="1";
//			}
//		System.out.println("strPage >>"+strPage);
//
//		int page=Integer.parseInt(strPage);
//		searchVo.setPage(page);
//		
//		searchVo.pageCalculate(total);
//
//		System.out.println("레코드 총수 "+ dao2.selectBoardCount(searchKeyword, "0" ));
//		
//		
//		System.out.println("====================");
//		System.out.println("clickPage : "+searchVo.getPage());
//		System.out.println("pageStart : "+searchVo.getPageStart());
//		System.out.println("pageEnd : "+searchVo.getPageEnd());
//		System.out.println("pageTot : "+searchVo.getTotPage());
//		System.out.println("rowStart : "+searchVo.getRowStart());
//		System.out.println("rowEnd : "+searchVo.getRowEnd());
//		
//		int rowStart=searchVo.getRowStart();
//		int rowEnd=searchVo.getRowEnd();
//		
////		select check query
//		System.out.println("btitle>>>>>>"+btitle);
//		System.out.println("bcontent>>>>>>"+bcontent);
//		
//		if(btitle.equals("btitle") && bcontent.equals("")) {
//			model.addAttribute("list", dao.list(rowStart,rowEnd,searchKeyword,"1"));
//			model.addAttribute("totRowCnt", dao2.selectBoardCount(searchKeyword,"1"));
//			System.out.println("gogo >list1");
//		}else if(btitle.equals("") && bcontent.equals("bcontent")) {
//			model.addAttribute("list", dao.list(rowStart,rowEnd,searchKeyword,"2"));
//			model.addAttribute("totRowCnt", dao2.selectBoardCount(searchKeyword,"2"));
//			System.out.println("gogo >list2");
//		}else if(btitle.equals("btitle") && bcontent.equals("bcontent")) {
//			model.addAttribute("list", dao.list(rowStart,rowEnd,searchKeyword,"3"));
//			model.addAttribute("totRowCnt", dao2.selectBoardCount(searchKeyword,"3"));
//			System.out.println("gogo >list3");
//		}else if(btitle.equals("") && bcontent.equals("")) {
//			model.addAttribute("list", dao.list(rowStart,rowEnd,searchKeyword,"0"));
//			model.addAttribute("totRowCnt", dao2.selectBoardCount(searchKeyword,"0"));
//			System.out.println("gogo >list0");
//		}
////		
////		model.addAttribute("totalcnt", total);
////		model.addAttribute("list", dao.list(rowStart,rowEnd));
//		model.addAttribute("searchVo",searchVo);
////		
//		return "list";
//	}
	
	@RequestMapping("/write_view")
	public String write_view() {
		System.out.println("pass write_view()");
		return "write_view";
	}
	@RequestMapping("/write"   )
	public String write(HttpServletRequest request,
			Model model) throws Exception {
		System.out.println("pass write()");
		
//		model.addAttribute("request", request);
//		
//		commandInp=new BWriteService();
//		commandInp.execute(model);
		
//		use mybatis
		String attachPath="resources\\upload\\";
		String uploadPath=
				request.getSession().getServletContext()
				.getRealPath("/");
		String path=uploadPath+attachPath;
		MultipartRequest req=
				new MultipartRequest(request, path,
						10*1024*1024,"UTF-8",
						new DefaultFileRenamePolicy());
		
		String bname=req.getParameter("bname");
		String btitle=req.getParameter("btitle");
		String bcontent=req.getParameter("bcontent");
		String fName=req.getFilesystemName("file");//**
		if(fName==null)
			fName="";
		
		IDao dao=sqlSession.getMapper(IDao.class);
		
		
		dao.write(bname, btitle, bcontent, fName);
		int currbid=dao.maxbid();
		dao.replywrite(currbid,bname, btitle, bcontent);
//		CURRVAL은 단독으로 사용 오류남
		
		return "redirect:list";
	}
	@RequestMapping("/download")
	public String download(HttpServletRequest request,
			HttpServletResponse response,
			Model model) throws Exception {
		System.out.println("pass download()");
		String path=request.getParameter("p");
		String fname=request.getParameter("f");
		String bid=request.getParameter("bid");
		
		response.setHeader("Content-Disposition", 
				"Attachment;filename="
		+URLEncoder.encode(fname,"utf-8"));//첨부처리, 한글처리
		//다운
		String attachPath="resources\\upload\\";
		String realPath=request.getSession()
				.getServletContext()
				.getRealPath(attachPath)+"\\"+fname;
		
		FileInputStream fin=new FileInputStream(realPath);
		ServletOutputStream sout=response.getOutputStream();
		
		byte[] buf=new byte[1024];
		int size=0;
		
		while ((size=fin.read(buf, 0, 1024))!=-1) {
			sout.write(buf, 0, size);
		}
		fin.close();
		sout.close();
		
		return "content_view?bid="+bid;
		
	}
	
	
	
	@RequestMapping("/content_view")
	public String content_view(HttpServletRequest request,
			Model model) {
		System.out.println("pass content_view()");
//		model.addAttribute("request", request);
//		commandInp=new BContentViewService();
//		commandInp.execute(model);
		String bid=request.getParameter("bid");
		IDao dao=sqlSession.getMapper(IDao.class);
		dao.upHit(bid);//카운트증가
		BoardDto dto=dao.contentView(bid);//상세뷰
		model.addAttribute("content_view", dto);
		
		return "content_view";
	}
	@RequestMapping(value = "/modify",method = RequestMethod.POST)
	public String modify(HttpServletRequest request,
			Model model) {
		System.out.println("pass modify()");
		//수정구현
//		model.addAttribute("request", request);
//		commandInp=new BModifyService();
//		commandInp.execute(model);
		
		String bid=request.getParameter("bid");
		String bname=request.getParameter("bname");
		String btitle=request.getParameter("btitle");
		String bcontent=request.getParameter("bcontent");
		IDao dao=sqlSession.getMapper(IDao.class);
		dao.modify(bid, bname, btitle, bcontent);
		
		return "redirect:list";
	}
	
	@RequestMapping(value = "/delete")
	public String delete(HttpServletRequest request,
			Model model) {
		System.out.println("pass delete()");
		//delete 구현
//		model.addAttribute("request", request);
//		commandInp=new BDeleteService();
//		commandInp.execute(model);
		
		String bid=request.getParameter("bid");
		IDao dao=sqlSession.getMapper(IDao.class);
		dao.delete(bid);
		
		return "redirect:list";
	}
	
	@RequestMapping(value = "/reply_view")
	public String reply_view(HttpServletRequest request,
			Model model) {
		System.out.println("pass reply_veiw()");
//		String bid=request.getParameter("bid");
//		model.addAttribute("request", request);
//		commandInp=new BReplyViewService();
//		commandInp.execute(model);
		
		String bid=request.getParameter("bid");
		IDao dao=sqlSession.getMapper(IDao.class);
		BoardDto dto=dao.reply_view(bid);// 답변뷰
		model.addAttribute("reply_view", dto);
		
		return "reply_view";
	}
	
	@RequestMapping(value = "/reply")
	public String reply(HttpServletRequest request,
			Model model) {
		System.out.println("pass reply()");
//		model.addAttribute("request", request);
//		commandInp=new BReplyService();
//		commandInp.execute(model);
		
		String bid=request.getParameter("bid");
		String bname=request.getParameter("bname");
		String btitle=request.getParameter("btitle");
		String bcontent=request.getParameter("bcontent");
		String bgroup=request.getParameter("bgroup");
		String bstep=request.getParameter("bstep");
		String bindent=request.getParameter("bindent");
		
		IDao dao=sqlSession.getMapper(IDao.class);
		dao.stepup(bgroup, bstep);
		dao.reply(bid, bname, btitle, 
				bcontent, bgroup,
				bstep, bindent);
		
		return "redirect:list";
	}
	
	
	
}
