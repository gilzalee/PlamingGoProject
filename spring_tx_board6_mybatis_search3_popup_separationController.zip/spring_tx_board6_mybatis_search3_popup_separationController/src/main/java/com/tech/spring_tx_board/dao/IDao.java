package com.tech.spring_tx_board.dao;
import java.util.ArrayList;

import com.tech.spring_tx_board.dto.BoardDto;
public interface IDao {
	public ArrayList<BoardDto> list(int start, int end,String searchKeyword,String selNum);
//	public ArrayList<BDto> list0(int start,int end,String searchKeyword);
//	public ArrayList<BDto> list1(int start,int end,String searchKeyword);
//	public ArrayList<BDto> list2(int start,int end,String searchKeyword);
//	public ArrayList<BDto> list3(int start,int end,String searchKeyword);
	
	
//	public int selectBoardCount(String searchKeyword,String selNum);
//	public int selectBoard2Count0(String searchKeyword);
//	public int selectBoard2Count1(String searchKeyword);
//	public int selectBoard2Count2(String searchKeyword);
//	public int selectBoard2Count3(String searchKeyword);
	
	public void write(String bname,
			String btitle, String bcontent, String fName);
	
	public void replywrite(int bid,String bname,
			String btitle, String bcontent);
	public BoardDto contentView(String seqid);
	public void upHit(String strid);
	public void modify(String bid, String bname,
			String btitle, String bcontent);
	public void delete(String bid);
	public BoardDto reply_view(String vbid);
	public void reply(String bid, String bname,
			String btitle, String bcontent,
			String bgroup, String bstep,
			String bindent);
	public void stepup(	String bgroup, String bstep);
	public int maxbid();
	
	
}
