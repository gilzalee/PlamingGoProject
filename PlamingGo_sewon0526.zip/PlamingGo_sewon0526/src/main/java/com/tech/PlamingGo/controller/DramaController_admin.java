package com.tech.PlamingGo.controller;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;
import com.tech.PlamingGo.dao.DramaDao;

@Controller
public class DramaController_admin {

	@Autowired
	private SqlSession sqlSession;
	

	@RequestMapping("drama/insert")
	public String insert() {
		System.out.println("01. insert 지나감");
		return "drama/insert";
	}
	
	@RequestMapping("drama/insert_page")
	public String insert_page(HttpServletRequest request, Model model) throws Exception{
		System.out.println("02. insert_page 지나감");
		// Mybatis
		// 파일 업로드 될 경로
		String attachPath = "resources\\upload\\";
		String uploadPath = 
				request.getSession().getServletContext().getRealPath("/");
		String path = uploadPath + attachPath;
		
		// 파일 첨부 (MultipartRequest 이용 → cos.jar 라이브러리 필요!)
		// request객체 + 저장 될 서버 경로 + 파일의 최대 크기 + 인코딩 방식 + 중복 파일 처리 방식
		MultipartRequest req =
				new MultipartRequest(request, path, 
						10*1024*1024, "UTF-8", new DefaultFileRenamePolicy());
			
		// enctype을 'multipart/form-data'로 선언하고 submit한 데이터들은 
		// request 객체가 아닌 MultipartRequest객체인 req로 불러와야 함
		// 파라미타 값
		String img = req.getFilesystemName("img");
		String title = req.getParameter("title");
		System.out.println(title);					// 값이 들어오는지 확인
		/* String rating = req.getParameter("rating"); */
		String opendate = req.getParameter("opendate");
		String nation = req.getParameter("nation");
		String age = req.getParameter("age");
		System.out.println(age);
		String epi = req.getParameter("epi");
		String director = req.getParameter("director");
		String actor = req.getParameter("actor");
		String genre = req.getParameter("genre");
		System.out.println(genre);
		String summary = req.getParameter("summary");
		
		// Mybatis 연결
		DramaDao dramadao = sqlSession.getMapper(DramaDao.class);
		dramadao.insert_page(img, title, opendate, nation, age, epi, director, actor, genre, summary);
		
		return "redirect:../drama";
	}
	
	
	
	
	// 05.	드라마 상세보기 수정
	@RequestMapping("drama/detail_modify")
	public String detail_modify() {
		
		return "drama/detail_modify";
	}
	
	// 06.	드라마 상세보기 삭제
	@RequestMapping("drama/detail_delete")
	public String detail_delete() {
		
		return "drama/detail_delete";
	}

}
