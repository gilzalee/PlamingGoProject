package com.tech.PlamingGo.dao;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.tech.PlamingGo.dto.JoinDto;

@Repository
public class JoinDaoImpl implements JoinDao{
	
	@Inject SqlSession sql;

	@Override
	public JoinDto reg(String user_id, String user_pw, String user_email, String user_name, String user_birth,
			int user_gender, String user_phone) {
		// TODO Auto-generated method stub
		return null;
	}

}
