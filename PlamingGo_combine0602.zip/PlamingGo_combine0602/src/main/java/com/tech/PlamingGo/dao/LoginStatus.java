package com.tech.PlamingGo.dao;

import com.tech.PlamingGo.dto.JoinDto;

public class LoginStatus implements JoinDao {

	@Override
	public int logstatus(int b) {
		int x = b;
		return x;
	}

	@Override
	public void register(String user_id, String user_pw, String user_email, String user_name, String user_birth,
			int user_gender, String user_phone) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public JoinDto login(String login_Id, String login_pw) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public JoinDto mypage(String user_code) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void modi(String modiid,String modiname, String modimail, String modiphone) {
		// TODO Auto-generated method stub
		
	}

	
}
