package com.tech.PlamingGo.controller;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.tech.PlamingGo.dao.DramaDao;
import com.tech.PlamingGo.dao.MovieDao;
import com.tech.PlamingGo.dto.DramaDto;
import com.tech.PlamingGo.dto.MovieDto;


@Controller
public class MovieController {
	
	// SqlSession 
	// @AutoWired : 각 상황의 타입에 맞는 loC컨테이너 안에 존재하는 Bean 자동 주입
	@Autowired
	private SqlSession sqlSession;
	
	
	@RequestMapping("/movie")
	public String Moviecon(Model model, HttpServletRequest request) {
		MovieDao dao = sqlSession.getMapper(MovieDao.class);
		model.addAttribute("movie", dao.getmovielist());

		return "movie";

	}
	@RequestMapping("/moviedetail")
	public String Moviedetail(Model model, HttpServletRequest request) {
		String movie_code = request.getParameter("movie_code");
		MovieDao dao = sqlSession.getMapper(MovieDao.class);
		MovieDto Mdto = dao.moviedetail(movie_code);
		model.addAttribute("moviedetail", Mdto);

		return "moviedetail";

	}
}
