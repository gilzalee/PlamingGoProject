package com.tech.PlamingGo.dto;

import java.sql.Date;

public class CustomDto {
	private int no_num;
	private String no_id;
	private String no_title;
	private String no_content;
	private Date no_date;
	private int no_hits;
	private int no_group;
	private int no_step;
	private int no_indent;
	private String no_fileSrc;
	
	public int getNo_num() {
		return no_num;
	}
	public void setNo_num(int no_num) {
		this.no_num = no_num;
	}
	public String getNo_id() {
		return no_id;
	}
	public void setNo_id(String no_id) {
		this.no_id = no_id;
	}
	public String getNo_title() {
		return no_title;
	}
	public void setNo_title(String no_title) {
		this.no_title = no_title;
	}
	public String getNo_content() {
		return no_content;
	}
	public void setNo_content(String no_content) {
		this.no_content = no_content;
	}
	public Date getNo_date() {
		return no_date;
	}
	public void setNo_date(Date no_date) {
		this.no_date = no_date;
	}
	public int getNo_hits() {
		return no_hits;
	}
	public void setNo_hits(int no_hits) {
		this.no_hits = no_hits;
	}
	public int getNo_group() {
		return no_group;
	}
	public void setNo_group(int no_group) {
		this.no_group = no_group;
	}
	public int getNo_step() {
		return no_step;
	}
	public void setNo_step(int no_step) {
		this.no_step = no_step;
	}
	public int getNo_indent() {
		return no_indent;
	}
	public void setNo_indent(int no_indent) {
		this.no_indent = no_indent;
	}
	public String getNo_fileSrc() {
		return no_fileSrc;
	}
	public void setNo_fileSrc(String no_fileSrc) {
		this.no_fileSrc = no_fileSrc;
	}
	
	
}
